package com.wallet.controller;

import com.wallet.entity.*;
import com.wallet.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;




import java.time.LocalDateTime;
import java.util.*;

@RestController
public class WalletController {
    @Autowired
    private UserRepository userRepo;

    @Autowired
    private TransactionRepository txnRepo;

    @Autowired
    private ProductRepository productRepo;

    @PostMapping("/fund")
    public Map<String, Object> fund(@RequestBody Map<String, Double> body, Authentication auth) {
        User user = userRepo.findByUsername(auth.getName()).get();
        double amt = body.get("amt");
        user.setBalance(user.getBalance() + amt);
        userRepo.save(user);

        txnRepo.save(new Transaction("credit", amt, user.getBalance(), LocalDateTime.now(), user));
        return Map.of("balance", user.getBalance());
    }

    @PostMapping("/pay")
    public ResponseEntity<?> pay(@RequestBody Map<String, Object> body, Authentication auth) {
        try {
            String toUser = (String) body.get("to");
            Object amtObj = body.get("amt");

            if (toUser == null || amtObj == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Both 'to' and 'amt' fields are required"));
            }

            double amt;
            try {
                amt = ((Number) amtObj).doubleValue();
            } catch (Exception e) {
                return ResponseEntity.badRequest().body(Map.of("error", "'amt' must be a valid number"));
            }

            if (amt <= 0) {
                return ResponseEntity.badRequest().body(Map.of("error", "Amount must be greater than zero"));
            }

            User from = userRepo.findByUsername(auth.getName())
                    .orElseThrow(() -> new RuntimeException("Sender not found"));

            User to = userRepo.findByUsername(toUser)
                    .orElseThrow(() -> new RuntimeException("Recipient not found"));

            if (from.getBalance() < amt) {
                return ResponseEntity.badRequest().body(Map.of("error", "insufficient funds or recipient doesn’t exist."));
            }

            from.setBalance(from.getBalance() - amt);
            to.setBalance(to.getBalance() + amt);
            userRepo.saveAll(List.of(from, to));

            txnRepo.save(new Transaction("debit", amt, from.getBalance(), LocalDateTime.now(), from));
            txnRepo.save(new Transaction("credit", amt, to.getBalance(), LocalDateTime.now(), to));

            return ResponseEntity.ok(Map.of("balance", from.getBalance()));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of(" insufficient funds or recipient doesn’t exist.", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", "An unexpected error occurred"));
        }
    }
    @Value("${currency.api.key}")
    private String currencyApiKey="cur_live_R8CkbnhbUncu1lQNAq4e2IjMHJbCviBAiBissMYB";

    @GetMapping("/bal")
    public ResponseEntity<?> getBalance(@RequestParam(required = false) String currency, Authentication auth) {
        User user = userRepo.findByUsername(auth.getName()).get();
        double bal = user.getBalance();

        if (currency != null) {
            try {
                // Construct API URL
                String apiUrl = "https://api.currencyapi.com/v3/latest?apikey=" + currencyApiKey + "&base_currency=INR&currencies=" + currency.toUpperCase();

                RestTemplate restTemplate = new RestTemplate();
                Map response = restTemplate.getForObject(apiUrl, Map.class);

                // Navigate to the correct part of JSON to extract the rate
                Map<String, Object> data = (Map<String, Object>) response.get("data");
                Map<String, Object> currInfo = (Map<String, Object>) data.get(currency.toUpperCase());
                double rate = (double) currInfo.get("value");

                double converted = bal * rate;

                return ResponseEntity.ok(Map.of(
                        "balance", converted,
                        "currency", currency.toUpperCase()
                ));
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
                        Map.of("error", "Invalid currency or API error")
                );
            }
        }

        return ResponseEntity.ok(Map.of("balance", bal));
    }

    @GetMapping("/stmt")
    public List<Transaction> statement(Authentication auth) {
        User user = userRepo.findByUsername(auth.getName()).get();
        return txnRepo.findByUserOrderByTimestampDesc(user);
    }

    @PostMapping("/buy")
    public ResponseEntity<?> buy(@RequestBody Map<String, Long> body, Authentication auth) {
        try {
            Long pid = body.get("product_id");
            if (pid == null) {
                return ResponseEntity.badRequest().body(Map.of("error", "Missing 'product_id' in request"));
            }

            Product product = productRepo.findById(pid)
                    .orElseThrow(() -> new RuntimeException("Product not found"));

            User user = userRepo.findByUsername(auth.getName())
                    .orElseThrow(() -> new RuntimeException("User not found"));

            if (user.getBalance() < product.getPrice()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Insufficient balance"));
            }

            user.setBalance(user.getBalance() - product.getPrice());
            userRepo.save(user);

            txnRepo.save(new Transaction("debit", product.getPrice(), user.getBalance(), LocalDateTime.now(), user));

            return ResponseEntity.ok(Map.of(
                    "message", "Product purchased",
                    "balance", user.getBalance()
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of(" error:Insufficient balance or invalid product ", e.getMessage()));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "An unexpected error occurred"));
        }
    }

}
