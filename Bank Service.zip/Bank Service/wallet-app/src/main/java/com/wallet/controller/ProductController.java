package com.wallet.controller;

import java.util.Map;
import com.wallet.entity.Product;
import com.wallet.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;


import java.util.List;

@RestController
public class ProductController {
    @Autowired
    private ProductRepository productRepo;

    @PostMapping("/product")
    public ResponseEntity<?> add(@RequestBody Product product) {
        try {
            Product saved = productRepo.save(product);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(Map.of("id", saved.getId(), "message", "Product added"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Failed to add product"));
        }
    }

    @GetMapping("/product")
    public List<Product> all() {
        return productRepo.findAll();
    }
}


